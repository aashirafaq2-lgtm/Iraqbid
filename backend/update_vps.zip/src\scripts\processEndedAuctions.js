/**
 * Process Ended Auctions - Cron Job Script
 * 
 * This script should be run periodically (e.g., every 5 minutes) to:
 * 1. Find auctions that have ended
 * 2. Send notifications to winners
 * 3. Mark auctions as processed
 * 
 * Usage: node src/scripts/processEndedAuctions.js
 */

import pool from '../config/db.js';
import { notifyUser } from '../utils/notificationUtils.js';

async function processEndedAuctions() {
    console.log('🔍 Checking for ended auctions...');

    try {
        // Find all products where auction has ended but not yet processed
        const endedAuctions = await pool.query(`
      SELECT 
        p.id,
        p.title,
        p.highest_bidder_id,
        p.current_bid,
        p.seller_id,
        p.auction_end_time,
        winner.name as winner_name,
        winner.email as winner_email
      FROM products p
      LEFT JOIN users winner ON p.highest_bidder_id = winner.id
      WHERE p.status = 'approved'
        AND p.auction_end_time <= NOW()
        AND (p.auction_processed IS NULL OR p.auction_processed = false)
    `);

        if (endedAuctions.rows.length === 0) {
            console.log('✅ No ended auctions to process');
            return;
        }

        console.log(`📢 Found ${endedAuctions.rows.length} ended auction(s) to process`);

        for (const auction of endedAuctions.rows) {
            try {
                // If there's a winner, send notification
                if (auction.highest_bidder_id) {
                    await notifyUser(
                        auction.highest_bidder_id,
                        'Auction Won!',
                        `Congratulations! You won the auction for "${auction.title}" with a bid of $${auction.current_bid}`,
                        'auction_won',
                        auction.id
                    );
                    console.log(`  ✅ Notified winner for auction: ${auction.title}`);
                }

                // Notify seller that auction ended
                if (auction.seller_id) {
                    const message = auction.highest_bidder_id
                        ? `Your auction for "${auction.title}" has ended. Winner: ${auction.winner_name} ($${auction.current_bid})`
                        : `Your auction for "${auction.title}" has ended with no bids.`;

                    await notifyUser(
                        auction.seller_id,
                        'Auction Ended',
                        message,
                        'auction_ended',
                        auction.id
                    );
                    console.log(`  ✅ Notified seller for auction: ${auction.title}`);
                }

                // Mark auction as processed and change status
                const finalStatus = auction.highest_bidder_id ? 'sold' : 'ended';
                await pool.query(
                    `UPDATE products SET auction_processed = true, status = $1 WHERE id = $2`,
                    [finalStatus, auction.id]
                );
                console.log(`  ✅ Marked auction #${auction.id} as processed and ${finalStatus.toUpperCase()}: ${auction.title}`);

            } catch (error) {
                console.error(`  ❌ Error processing auction ${auction.id}:`, error.message);
            }
        }

        console.log('✅ Finished processing ended auctions');

    } catch (error) {
        console.error('❌ Error in processEndedAuctions:', error);
        throw error;
    }
}

// Run if called directly
if (import.meta.url === `file://${process.argv[1]}`) {
    processEndedAuctions()
        .then(() => {
            console.log('✅ Script completed');
            process.exit(0);
        })
        .catch((error) => {
            console.error('❌ Script failed:', error);
            process.exit(1);
        });
}

export default processEndedAuctions;
